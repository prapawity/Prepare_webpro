from django.apps import AppConfig


class DayoffConfig(AppConfig):
    name = 'dayoff'
