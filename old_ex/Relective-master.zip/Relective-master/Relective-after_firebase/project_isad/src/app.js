
import Vue from 'vue'
import BootstrapVue from 'bootstrap-vue'
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'
import 'node_modules/bootstrap/scss/bootstrap';
import 'node_modules/bootstrap-vue/src/index.scss';
Vue.use(BootstrapVue)