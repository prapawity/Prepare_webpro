<template>
  
</template>

<script>

  export default {
    name: 'auth-success',
    
  }
</script>

<style scoped>
  
</style>